# Elixir version of Yatzy Refactoring Kata

Make sure you have erlang/otp and elixir installed. Then in this directory:

    # To run unit tests:
    elixir -r yatzy.exs test_yatzy.exs

