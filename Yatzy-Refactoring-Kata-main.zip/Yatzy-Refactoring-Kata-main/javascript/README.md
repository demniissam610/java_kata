# JavaScript version of Yatzy Refactoring Kata

Make sure you have node.js and npm installed. Then in this directory:

    # To install mocha in node_modules:
    npm install

    # To run unit tests:
    node_modules/mocha/bin/mocha
    
    # To run unit tests in watch mode:
    node_modules/mocha/bin/mocha -w
    
